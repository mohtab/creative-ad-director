# Design lessons and model reality

## What to preserve from the STILLWATER example

Treat the supplied prompt as a director's treatment, continuity bible and edit specification, not merely a style incantation. Its durable pattern is:

- A concrete conversion goal (sell a stay) and campaign promise (quiet).
- An immediate destination reveal rather than an abstract slow opening.
- A human surrogate, a simple journey and an observable emotional payoff.
- Sensory proof through texture, warmth, water and spatial connection.
- A distinctive, product-world-specific memory cue: the resident's restrained interaction. It is not interchangeable glamour footage.
- A small set of persistent identities and props, explicit geography and action axis.
- Intentional omission of an unnecessary difficult motion (sitting down).
- A progression of scales and viewpoints with specific editorial functions.
- Sparse narration, sound bridges and musical change supporting the emotional peak.
- A final product-world image with compositional room for a clear invitation.
- Truth constraints: no invented amenities, ratings, prices or destination URL.

Do not generalize its fictional architecture, pale resident, wardrobe, thirteen shots, slow luxury pacing or woman protagonist to every brand. For software, show a verified workflow/result; for a physical product, demonstrate a relevant material/function; for food, show credible preparation/sensory cues; for an experience, let place/action generate the payoff. A metaphor must not misrepresent real performance.

## Critique of the example

The shot endpoints sum to 30 seconds. At 24 fps there are 720 frames. At 80 BPM a quarter-note lasts 0.75 seconds: 40 beats / ten 4/4 bars. All supplied cut boundaries are on both the beat and frame grid. The final completed text fade at 26.75 leaves a 3.25-second hold. The included fixture reproduces these checks from the user-supplied timing, not from a rendered video.

Risks: one image cannot verify unseen views; detailed topology and human/prop interaction may drift; fast inserts have little room for multi-action choreography; exact lenses/focus/audio and frame-perfect timestamps are not guaranteed; many negative clauses can dilute priorities. Preserve the strongest truths, simplify high-risk motion, and inspect each generated shot.

The original sound sections mix generation language ('create score', 'use exact VO') with later instructions to add narration/mix in edit. Resolve the intended audio pipeline explicitly. Branding is best composited from actual approved assets for spelling/logo control. The supplied image/video was not included with the example in this conversation, so no image fidelity or render quality was verified.

## Seedance 2.5 on Runway — dated documentation snapshot

Checked against official Runway documentation on 2026-09-11. Re-check before relying on these limits for a new production:
https://help.runwayml.com/hc/en-us/articles/53542207042323-Creating-with-Seedance-2-5
https://runway.com/product/seedance-2.5

- Single-generation multishot video: 4–30 seconds or Auto. Do not apply Seedance 2.0's old duration limits to 2.5.
- Native output resolutions listed: 480p, 720p, 1080p. A requested 4K master is a finishing/upscale target, not a documented native setting.
- The FAQ explicitly says timestamps guide pacing, not frame-accurate edit points. Enforce exact duration/cuts in post.
- Reference, Keyframe, Edit and Extend modes have different controls. Edit matches source duration/aspect; Extend matches aspect and returns new footage only, which must be assembled with the original.
- Up to 50 references are listed: up to 30 images, 10 videos and 10 audio clips. Each reference needs a named role. Do not fill the budget merely because it exists.
- Audio has an explicit generation toggle. Set it to match the actual pipeline.
- The cited spec does not establish user-selectable native FPS or guaranteed exact lens simulation. Verify actual output; conform to delivery FPS in edit.

Capability support is not a guarantee of faithful 13-shot execution. Try one-pass if appropriate, then repair or split only where necessary. For a separate 1.5-second editorial insert, respect native minimum clip length and trim a longer generated shot. Check costs before any authorized render; no render is authorized by merely creating the prompt.

## Seedance 2.5 on Higgsfield — compatibility notes

Official sources inspected during platform comparison; re-check limits and actual account controls before production:
https://higgsfield.ai/seedance/2.5
https://higgsfield.ai/blog/seedance-2-5-on-higgsfield-2026
https://higgsfield.ai/blog/seedance-2-5-pricing-2026

The product page advertises up to 30 seconds, up to 50 multimodal references, native 1080p, synchronized audio and region editing. The platform guide describes additional look/camera/motion controls and suite tools. These are vendor claims, not a tested guarantee that every control works for this model in the user's chosen surface. Verify the actual UI before giving click-by-click instructions or assuming control availability.

The guide distinguishes 4K upscaling from native 480p/720p/1080p. A separate pricing article omits 1080p in one passage, so use the generation screen and model-specific technical guide to resolve available settings. Marketing labels on examples do not prove native 4K.

Keep audience, promise, proof, story, continuity and CTA unchanged when moving the same concept between hosts. Adapt asset identifiers, settings, audio choices and any verified prompt limits. Deliver a Higgsfield settings/reference sheet alongside the portable master rather than dropping unsupported settings into prose. For mixed-lens or mixed-motion sequences, do not impose one conflicting global preset. Where controls do not apply, retain the intent in shot text or generate separate shots with appropriate handles.

Exact cuts, frame count, copy/logo fidelity, final VO/music mix and 4K finishing still require output inspection and editing. Native synchronized sound may be useful as ambience or scratch; it is not a guarantee of exact narration or beat placement. Neither platform superiority nor identical output quality has been benchmarked here.

Pricing, unlimited windows, queue speed and allowed clip lengths can depend on account/plan and mode. Check the live estimate and applicable rights before any spend or upload. Do not compare raw credit counts across vendors or repeat one vendor's competitor-pricing table as independently verified fact.
